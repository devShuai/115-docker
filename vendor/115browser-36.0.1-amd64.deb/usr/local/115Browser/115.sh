#!/bin/sh
APP_DIR=/usr/local/115Browser
cd "$APP_DIR" || exit 1
export LD_LIBRARY_PATH="$APP_DIR${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
exec "$APP_DIR/115Browser" "$@"
